﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clases
{
    public class NodoBicola
    {
        public string usuario;
        public NodoBicola siguiente;
    }
}
